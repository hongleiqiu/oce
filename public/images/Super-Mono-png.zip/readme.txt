----------------------------------------------------------------------
Super Mono Icon Set
by Double-J Design (http://www.doublejdesign.co.uk)
----------------------------------------------------------------------
Product Name:	Super Mono
Product Type:	Icon Set	
Quantity:	1728 Icons
File Format:	PNG
License Type:	Free, Standard and Extended

----------------------------------------------------------------------
TERMS OF USE
----------------------------------------------------------------------
This product may be used for free for personal and commerical use 
subject to the agreement to following license information. Any purchse
of licenses must be maed on Double-J Design website 
(http://www.doublejdesign.co.uk) 

All logos of Adobe application belong to Adobe.


----------------------------------------------------------------------
License Infomation
----------------------------------------------------------------------
1. Free License (Creative Common 3.0 Attribution)
Licensee is granted a non-exclusive, non-transferrable license 
to use the Work, for personal, commercial, and client projects. 
Licensee MUST attribute the work in the manner specified by the 
Licensor (but not in any way that suggests that they endorse 
you or your use of the work).

2. Standard License (Price: GBP 20.00)
Licensee is granted a non-exclusive, non-transferrable license 
to use the Work, royalty free, for personal, commercial, and 
client projects, including advertising, web design, software 
application, multimedia design, film, video, and computer games. 
Licensee may not use the Work in projects that it intends to 
sell or distribute.

3.Extended License (Price: GBP 75.00)
Licensee who has obtained an Extended license has a non-exclusive, 
non-transferrable rights to use the Work for in the course of its 
business and to otherwise copy, make and use the Work in its own 
products that it intends to sell or distribute.



Thank you for using our products and enjoy.

----------------------------------------------------------------------
Double-J Design
WEB: http://www.doublejdesign.co.uk
Email: info@doublejdesign.co.uk
----------------------------------------------------------------------
